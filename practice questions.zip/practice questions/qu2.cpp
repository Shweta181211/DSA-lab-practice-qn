#include <iostream>
#include <queue>
using namespace std;

int main() {
    int n;
    cin >> n;

    queue<int> q;
    for(int i = 0; i < n; i++) {
        int x;
        cin >> x;
        q.push(x);
    }

    for(int i = 0; i < n; i++) {
        int mn = q.front(); 
        int idx = 0;        

        for(int j = 0; j < n; j++) {
            int x = q.front(); q.pop();
            if(j < n - i) {
                if(x < mn) { 
                    mn = x; 
                    idx = j; 
                }
            }
            q.push(x);
        }

        for(int j = 0; j < n; j++) {
            int x = q.front(); q.pop();
            if(j != idx) {
                q.push(x);
            }
        }

        q.push(mn);
    }

    while(!q.empty()) {
        cout << q.front() << " ";
        q.pop();
    }
    return 0;
}

