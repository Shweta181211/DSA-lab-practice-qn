#include <iostream>
#include <queue>
#include <stack>
using namespace std;

int main() {
    int n;
    cin >> n;

    queue<int> students;
    for(int i=0;i<n;i++){
        int x;
        cin >> x;
        students.push(x);
    }

    stack<int> sandwiches;
    int s[1000];
    for(int i=0;i<n;i++) cin >> s[i];
    for(int i=n-1;i>=0;i--) sandwiches.push(s[i]);

    int countFail = 0;

    while(!students.empty() && !sandwiches.empty()) {
        if(students.front() == sandwiches.top()) {
            students.pop();
            sandwiches.pop();
            countFail = 0;      
        } else {
            students.push(students.front());
            students.pop();
            countFail++;       
            if(countFail == students.size()) break;
        }
    }

    cout << students.size();
    return 0;
}
