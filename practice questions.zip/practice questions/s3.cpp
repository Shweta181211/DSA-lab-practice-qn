#include <iostream>
#include <stack>
using namespace std;

int main() {
    int n; 
    cin >> n;
    int a[1005], ans[1005];
    for (int i = 0; i < n; i++) cin >> a[i];

    stack<int> st;                   
    for (int i = n - 1; i >= 0; i--) {
        while (!st.empty() && st.top() <= a[i]) st.pop();
        ans[i] = st.empty() ? -1 : st.top();
        st.push(a[i]);
    }

    for (int i = 0; i < n; i++) cout << ans[i] << " ";
    return 0;
}
