#include <iostream>
using namespace std;

int main() {
    int n; 
    cin >> n;
    int a[1000];
    for (int i = 0; i < n; i++) cin >> a[i];

    int zeros = 0;
    for (int i = 0; i + zeros < n; i++) {
        if (a[i] == 0) {
            if (i + zeros == n - 1) {           
                a[n - 1] = 0;
                n = n - 1;                     
                break;
            }
            zeros++;
        }
    }

    int i = n - 1, j = n - 1 + zeros;            
    while (i >= 0) {
        if (a[i] != 0) {
            if (j < 1000) a[j] = a[i];
            j--; i--;
        } else {
            if (j < 1000) a[j] = 0;              
            j--;
            if (j < 1000) a[j] = 0;
            j--; i--;
        }
    }

    for (int k = 0; k < n + zeros; k++)
        cout << a[k] << " ";
    return 0;
}
