#include <iostream>
#include <stack>
using namespace std;

int main() {
    int n;
    cin >> n;
    int A[1000];
    
    for(int i = 0; i < n; i++)
        cin >> A[i];

    stack<int> S;
    int B_last = -1; 

    int i = 0;
    while(i < n) {
        if(S.empty() || A[i] <= S.top()) {
            S.push(A[i]);
            i++;
        }
        else {
            if(S.top() <= B_last) {
                cout << "No";
                return 0;
            }
            B_last = S.top();
            S.pop();
        }
    }

    while(!S.empty()) {
        if(S.top() <= B_last) {
            cout << "No";
            return 0;
        }
        B_last = S.top();
        S.pop();
    }

    cout << "Yes";
    return 0;
}
