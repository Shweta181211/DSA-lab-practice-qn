#include <iostream>
#include <queue>
#include <stack>
using namespace std;

int main() {
    int n; 
    cin >> n;
    queue<int> q;
    for (int i = 0, x; i < n; i++) { cin >> x; q.push(x); }

    stack<int> st;
    int need = 1;

    while (!q.empty()) {
        if (q.front() == need) { q.pop(); need++; }
        else if (!st.empty() && st.top() == need) { st.pop(); need++; }
        else { st.push(q.front()); q.pop(); }
    }
    while (!st.empty() && st.top() == need) { st.pop(); need++; }

    cout << (need == n + 1 ? "Yes" : "No");
    return 0;
}
