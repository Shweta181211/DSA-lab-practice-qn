#include <iostream>
using namespace std;

bool isSubstr(const string &big, const string &small) {
    if (small.size() > big.size()) return false;
    for (size_t i = 0; i + small.size() <= big.size(); i++) {
        size_t j = 0;
        while (j < small.size() && big[i + j] == small[j]) j++;
        if (j == small.size()) return true;
    }
    return false;
}

int main() {
    string s; 
    cin >> s;                  
    int n = (int)s.size();
    bool ok = false;

    for (int i = 0; i < n - 2 && !ok; i++) {
        for (int j = i + 1; j < n - 1 && !ok; j++) {
            string A = s.substr(0, i + 1);
            string B = s.substr(i + 1, j - i);
            string C = s.substr(j + 1);

            if (isSubstr(A, B) && isSubstr(C, B)) ok = true;
            else if (isSubstr(B, A) && isSubstr(C, A)) ok = true;
            else if (isSubstr(A, C) && isSubstr(B, C)) ok = true;
        }
    }
    cout << (ok ? "YES" : "NO");
    return 0;
}
