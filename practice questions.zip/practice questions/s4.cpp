#include <iostream>
#include <stack>
using namespace std;

int main() {
    int n; 
    cin >> n;
    int t[1005], ans[1005];
    for (int i = 0; i < n; i++) cin >> t[i];

    stack<int> st;                       
    for (int i = n - 1; i >= 0; i--) {
        while (!st.empty() && t[st.top()] <= t[i]) st.pop();
        ans[i] = st.empty() ? 0 : st.top() - i;
        st.push(i);
    }

    for (int i = 0; i < n; i++) cout << ans[i] << " ";
    return 0;
}
