#include <iostream>
#include <stack>
using namespace std;

class MinStack {
    stack<long long> st;
    long long mn;
public:
    void push(long long x) {
        if (st.empty()) { st.push(x); mn = x; }
        else if (x >= mn) st.push(x);
        else { st.push(2*x - mn); mn = x; }    
    }

    void pop() {
        if (st.empty()) return;
        long long t = st.top(); st.pop();
        if (t < mn) mn = 2*mn - t;          
    }

    long long top() {
        if (st.empty()) return -1;
        long long t = st.top();
        if (t >= mn) return t;
        return mn;                             
    }

    long long getMin() {
        if (st.empty()) return -1;
        return mn;
    }

    bool empty() { return st.empty(); }
};

int main() {
    int q; 
    if(!(cin >> q)) return 0;
    MinStack ms;
    while (q--) {
        string op; cin >> op;
        if (op == "push") { long long x; cin >> x; ms.push(x); }
        else if (op == "pop") { ms.pop(); }
        else if (op == "peek") { cout << ms.top() << "\n"; }
        else if (op == "getMin") { cout << ms.getMin() << "\n"; }
    }
    return 0;
}
